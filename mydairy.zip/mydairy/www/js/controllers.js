angular.module('starter.controllers', [])

.controller('DashCtrl', function ($scope, Chats, $cordovaSQLite, $rootScope, $cordovaDialogs) {
    $scope.remove = function (chat, index) {

        $cordovaDialogs.confirm('Are you sure to delete', 'Confirmation', ['Cancel', 'Agree'])
            .then(function (buttonIndex) {
                if (buttonIndex == 1) {
                    $rootScope.chats.splice(index, 1);
                    $rootScope.db.transaction(
                        function (tx) {
                            var sql = "Delete from dairy where id=?";
                            tx.executeSql(sql, [chat]);
                        });
                }
            });


    };

    $rootScope.db.transaction(
        function (tx) {
            var sql = "SELECT * from dairy ORDER BY id DESC";
            tx.executeSql(sql, []
                , function (tx, results) {

                    var len = results.rows.length
                        , messages = []
                        , i = 0;
                    for (; i < len; i = i + 1) {
                        messages.push(results.rows.item(i));
                    }
                    $rootScope.chats = messages;

                }
            );
        });
})

.controller('ChatsCtrl', function ($scope, Chats) {
    // With the new view caching in Ionic, Controllers are only called
    // when they are recreated or on app start, instead of every page change.
    // To listen for when this page is active (for example, to refresh data),
    // listen for the $ionicView.enter event:
    //
    //$scope.$on('$ionicView.enter', function(e) {
    //});

    $scope.categories = Chats.categories();

})

.controller('ChatDetailCtrl', function ($scope, $stateParams, Chats) {
        $scope.chat = Chats.get($stateParams.chatId);

    })
    .controller('NewCtrl', function ($scope, $stateParams, Chats, $cordovaSQLite, $rootScope, $ionicLoading, $location) {
        $rootScope.parent_category = $stateParams.chatId;
        $scope.cat_info = Chats.getcat($stateParams.chatId);
        var date = new Date();
        $scope.message = {
            title: ''
            , datetime: date
            , description: ''
        }

        $scope.submit = function () {
            $ionicLoading.show({
                template: 'Processing...'
                , duration: 1500
            })
            if ($scope.message.title != "" && $scope.message.desp != "") {

                $rootScope.db.transaction(
                    function (tx) {
                        var sql = "INSERT INTO dairy (subject, description, category,datetime) VALUES (?,?,?,?)";
                        tx.executeSql(sql, [$scope.message.title, $scope.message.description, $stateParams.chatId, date]
                            , function (tx, results) {

                                var lastInsertId = results.insertId;
                                var item = $scope.message = {
                                    id: lastInsertId
                                    , subject: $scope.message.title
                                    , datetime: date
                                    , description: $scope.message.description
                                }

                                $rootScope.chats.splice(0, 0, item);
                                $scope.message = {
                                    title: ''
                                    , description: ''
                                }
                                $location.path('/dash');

                            }
                        );
                    });


            }

        }
    })

.controller('AccountCtrl', function ($scope, $cordovaSQLite, $rootScope, $cordovaDialogs, $timeout, $ionicPopup) {
    $scope.clearcache = function () {
        $cordovaDialogs.confirm('Are you sure to delete', 'Confirmation', ['Cancel', 'Agree'])
            .then(function (buttonIndex) {
                if (buttonIndex == 1) {
                    $rootScope.db.transaction(
                        function (tx) {
                            var sql = "DELETE FROM dairy";
                            tx.executeSql(sql, []);
                        });
                    $ionicPopup.alert({
                        title: 'Information'
                        , template: 'Your new dairy is ready now....'
                    });

                    $rootScope.chats = [];
                }
            });
    }
});
