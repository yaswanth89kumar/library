angular.module('starter.services', [])

.factory('Chats', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var chats = [{
    id: 0,
    name: 'Ben Sparrow',
    lastText: 'You on your way?',
    face: 'img/ben.png'
  }, {
    id: 1,
    name: 'Max Lynx',
    lastText: 'Hey, it\'s me',
    face: 'img/max.png'
  }, {
    id: 2,
    name: 'Adam Bradleyson',
    lastText: 'I should buy a boat',
    face: 'img/adam.jpg'
  }, {
    id: 3,
    name: 'Perry Governor',
    lastText: 'Look at my mukluks!',
    face: 'img/perry.png'
  }, {
    id: 4,
    name: 'Mike Harrington',
    lastText: 'This is wicked good ice cream.',
    face: 'img/mike.png'
  }];

var categories = [{
    id: 1,
    name: 'Awesome',

  },{
    id: 2,
    name: 'Cool',

  },{
    id: 3,
    name: 'Dance',

  },{
    id: 4,
    name: 'Entertain',

  },{
    id: 5,
    name: 'Fashion',

  },{
    id: 6,
    name: 'Great',

  },{
    id: 7,
    name: 'Help',

  },{
    id: 8,
    name: 'Incrediable',

  },{
    id: 9,
    name: 'Journey',

  },{
    id: 10,
    name: 'Love',

  },{
    id: 11,
    name: 'Mansoon',

  },{
    id: 12,
    name: 'Memory',

  },{
    id: 13,
    name: 'Noise',

  },{
    id: 14,
    name: 'Operating',

  },{
    id: 15,
    name: 'Others',

  },{
    id: 16,
    name: 'Popular',

  },{
    id: 17,
    name: 'Question',

  },{
    id: 18,
    name: 'Random',

  },{
    id: 19,
    name: 'Showing',

  },{
    id: 20,
    name: 'Travel',

  },{
    id: 21,
    name: 'Under',

  },{
    id: 22,
    name: 'violent',

  },{
    id: 23,
    name: 'Watching',

  },{
    id: 24,
    name: 'Yawn',

  },{
    id: 25,
    name: 'zoom',

  }];

  return {
    all: function() {
      return chats;
    },
      categories: function() {
      return categories;
    },
      getcat: function(chatId) {
      for (var i = 0; i < categories.length; i++) {
        if (categories[i].id === parseInt(chatId)) {
          return categories[i];
        }
      }
      return null;
    },
    remove: function(chat) {
      chats.splice(chats.indexOf(chat), 1);
    },
    get: function(chatId) {
      for (var i = 0; i < chats.length; i++) {
        if (chats[i].id === parseInt(chatId)) {
          return chats[i];
        }
      }
      return null;
    }
  };
});
